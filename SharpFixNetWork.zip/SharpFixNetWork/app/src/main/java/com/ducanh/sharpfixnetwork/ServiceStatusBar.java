package com.ducanh.sharpfixnetwork;

import android.content.ComponentName;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.provider.Settings;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

@RequiresApi(api = Build.VERSION_CODES.N)
public class ServiceStatusBar extends TileService {
    private final static String LOG_TAG = ServiceStatusBar.class.getSimpleName ();
    @Override
    public void onTileAdded() {
        Log.d (LOG_TAG,"onTileAdded");
    }

    @Override
    public void onTileRemoved() {
        Log.d (LOG_TAG,"onTileRemoved");
    }

    @Override
    public void onStartListening() {
        Log.d (LOG_TAG,"onStartListening");
    }

    @Override
    public void onStopListening() {
        Log.d (LOG_TAG,"onStopListening");
    }

    @Override
    public void onClick() {
        Intent intent = new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY);
        intent.setFlags (Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity (intent);
    }
}
